### Test Patches ###

These patches are applied when the automated pull-tester
tests each pull and when master is tested using jenkins.
You can find more information about the tests run at
[http://jenkins.bluematt.me/pull-tester/files/
](http://jenkins.bluematt.me/pull-tester/files/)
